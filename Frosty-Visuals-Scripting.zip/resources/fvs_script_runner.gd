extends Node
class_name FVSScriptRunner

## Attach this node as a child of any scene node to run an FVS visual script at runtime.
##
## Usage:
## 1. Add FVSScriptRunner as a child of your CharacterBody2D / Node2D / etc.
## 2. Assign an FVSScript resource (.tres) to the 'visual_script' property
## 3. The visual script executes automatically based on its event nodes

@export var visual_script: Resource  ## Assign your FVSScript resource here
@export var auto_run: bool = true


var _executor: FVSScriptExecutor


func _ready() -> void:
	if not visual_script:
		push_warning("FVSScriptRunner: No visual_script assigned on ", get_path())
		return

	_executor = FVSScriptExecutor.new()
	# IMPORTANT: owner is the parent (the actual game object that should move)
	_executor.setup(visual_script, get_parent())

	if auto_run:
		_executor.execute_event("EventStart")


func _process(delta: float) -> void:
	if _executor:
		_executor._context["delta"] = delta
		_executor.execute_event("EventProcess", {"delta": delta})


func _physics_process(delta: float) -> void:
	if _executor:
		_executor._context["delta"] = delta
		_executor.execute_event("EventPhysicsProcess", {"delta": delta})


func _input(event: InputEvent) -> void:
	if _executor:
		_executor._context["input_event"] = event
		_executor.execute_event("EventInput", {"event": event})


func trigger_event(event_type: String, args: Dictionary = {}) -> void:
	if _executor:
		_executor.execute_event(event_type, args)


func get_variable(var_name: String) -> Variant:
	if _executor:
		return _executor._context.get(var_name, null)
	return null


func set_variable(var_name: String, value: Variant) -> void:
	if _executor:
		_executor._context[var_name] = value
