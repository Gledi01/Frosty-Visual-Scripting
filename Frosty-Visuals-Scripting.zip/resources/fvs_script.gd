@tool
extends Resource
class_name FVSScript

## FVS - Frosty Visual Script Resource
## Stores all nodes and connections for a visual script graph.

@export var graph_nodes: Array[Dictionary] = []
@export var graph_connections: Array[Dictionary] = []
@export var graph_offset: Vector2 = Vector2.ZERO
@export var graph_zoom: float = 1.0
@export var script_name: String = "New FVS Script"
@export var extends_class: String = "Node"

signal graph_changed


func _init() -> void:
	if graph_nodes.is_empty():
		add_node({
			"id": "start_0",
			"type": "EventStart",
			"position": Vector2(100, 100),
			"data": {}
		})


func add_node(node_data: Dictionary) -> void:
	if not node_data.has("id"):
		node_data["id"] = _generate_id()
	graph_nodes.append(node_data)
	emit_changed()
	graph_changed.emit()


func remove_node(node_id: String) -> void:
	for i in graph_nodes.size():
		if graph_nodes[i]["id"] == node_id:
			graph_nodes.remove_at(i)
			break
	graph_connections = graph_connections.filter(func(c):
		return c["from_node"] != node_id and c["to_node"] != node_id
	)
	emit_changed()
	graph_changed.emit()


func add_connection(from_node: String, from_port: int, to_node: String, to_port: int) -> void:
	var conn = {
		"from_node": from_node,
		"from_port": from_port,
		"to_node": to_node,
		"to_port": to_port
	}
	for existing in graph_connections:
		if existing["from_node"] == from_node and existing["from_port"] == from_port \
		and existing["to_node"] == to_node and existing["to_port"] == to_port:
			return
	graph_connections.append(conn)
	emit_changed()
	graph_changed.emit()


func remove_connection(from_node: String, from_port: int, to_node: String, to_port: int) -> void:
	for i in graph_connections.size():
		var c = graph_connections[i]
		if c["from_node"] == from_node and c["from_port"] == from_port \
		and c["to_node"] == to_node and c["to_port"] == to_port:
			graph_connections.remove_at(i)
			break
	emit_changed()
	graph_changed.emit()


func update_node_position(node_id: String, position: Vector2) -> void:
	for i in graph_nodes.size():
		if graph_nodes[i]["id"] == node_id:
			graph_nodes[i]["position"] = position
			emit_changed()
			return


func update_node_data(node_id: String, key: String, value: Variant) -> void:
	for i in graph_nodes.size():
		if graph_nodes[i]["id"] == node_id:
			if not graph_nodes[i].has("data"):
				graph_nodes[i]["data"] = {}
			graph_nodes[i]["data"][key] = value
			emit_changed()
			return


func get_node_by_id(node_id: String) -> Dictionary:
	for node in graph_nodes:
		if node["id"] == node_id:
			return node
	return {}


func duplicate_graph() -> Dictionary:
	return {
		"nodes": graph_nodes.duplicate(true),
		"connections": graph_connections.duplicate(true),
		"offset": graph_offset,
		"zoom": graph_zoom,
		"name": script_name,
		"extends": extends_class
	}


func restore_graph(state: Dictionary) -> void:
	graph_nodes = state.get("nodes", []).duplicate(true)
	graph_connections = state.get("connections", []).duplicate(true)
	graph_offset = state.get("offset", Vector2.ZERO)
	graph_zoom = state.get("zoom", 1.0)
	script_name = state.get("name", "New FVS Script")
	extends_class = state.get("extends", "Node")
	emit_changed()
	graph_changed.emit()


func _generate_id() -> String:
	return "%s_%d" % [randi_range(1000, 9999), Time.get_ticks_msec()]


## Generate complete GDScript from the visual graph
func compile_to_gdscript() -> String:
	var executor = FVSScriptExecutor.new()
	executor.vs_script = self
	return executor.generate_full_code()
