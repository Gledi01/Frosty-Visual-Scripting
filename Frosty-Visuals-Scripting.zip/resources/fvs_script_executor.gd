extends RefCounted
class_name FVSScriptExecutor

## Runtime execution engine for FVS (Frosty Visual Scripting).
## Traverses the graph and executes node logic. Also generates full GDScript.

const FVSNodeDefinitions = preload("res://addons/fvs/nodes/fvs_node_definitions.gd")

var vs_script: Resource  # FVSScript
var _context: Dictionary = {}
var _owner_node: Node


func setup(script: Resource, owner: Node) -> void:
	vs_script = script
	_owner_node = owner
	_context.clear()
	_context["self"] = owner
	_context["owner"] = owner


func execute_event(event_type: String, args: Dictionary = {}) -> void:
	if not vs_script:
		return
	for key in args:
		_context[key] = args[key]
	for node_data in vs_script.graph_nodes:
		if node_data["type"] == event_type:
			_execute_node(node_data["id"], args)
			# Continue to next matching event (allow multiple)
			# break  # removed so multiple event nodes of same type can run


func _execute_node(node_id: String, args: Dictionary = {}) -> Variant:
	var node_data = vs_script.get_node_by_id(node_id)
	if node_data.is_empty():
		return null

	var node_type = node_data.get("type", "")
	var props = node_data.get("data", {})

	match node_type:
		# ── Events ──
		"EventStart", "EventProcess", "EventPhysicsProcess", "EventInput":
			_follow_flow(node_id, 0)

		"EventSignal":
			if _owner_node:
				var sig_name: String = str(props.get("signal_name", ""))
				if sig_name and _owner_node.has_signal(sig_name):
					_owner_node.emit_signal(sig_name)
			_follow_flow(node_id, 0)

		# ── Flow Control ──
		"FlowBranch":
			var condition = _evaluate_input(node_id, 1)
			if condition:
				_follow_flow(node_id, 0)
			else:
				_follow_flow(node_id, 1)

		"FlowWhile":
			var safety = 0
			while _evaluate_input(node_id, 1) and safety < 10000:
				_follow_flow(node_id, 0)
				safety += 1
			_follow_flow(node_id, 1)

		"FlowForRange":
			var start = _evaluate_input(node_id, 1) if _has_connection_to(node_id, 1) else int(props.get("start", 0))
			var end_val = _evaluate_input(node_id, 2) if _has_connection_to(node_id, 2) else int(props.get("end", 10))
			var step = int(props.get("step", 1))
			if step == 0:
				step = 1
			for i in range(start, end_val, step):
				_context["__loop_index_" + node_id] = i
				_follow_flow(node_id, 0)
			_follow_flow(node_id, 2)

		"FlowBreak":
			pass

		"FlowReturn":
			return _evaluate_input(node_id, 1)

		"FlowSequence":
			_follow_flow(node_id, 0)
			_follow_flow(node_id, 1)
			_follow_flow(node_id, 2)

		# ── Variables ──
		"VarSet", "DeclareVar":
			var var_name: String = str(props.get("var_name", "var"))
			var value = _evaluate_input(node_id, 1)
			_context[var_name] = value
			_follow_flow(node_id, 0)

		# ── Node Operations (FIXED) ──
		"NodeSetPosition":
			var target = _resolve_target(node_id, 1)
			var pos = _evaluate_input(node_id, 2)
			if target is Node2D and pos is Vector2:
				target.position = pos
			elif target is Node3D and pos is Vector3:
				target.position = pos
			_follow_flow(node_id, 0)

		"NodeSetVelocity":
			var target = _resolve_target(node_id, 1)
			var vel = _evaluate_input(node_id, 2)
			if target and vel != null:
				if target is CharacterBody2D and vel is Vector2:
					target.velocity = vel
				elif target is CharacterBody3D and vel is Vector3:
					target.velocity = vel
				elif "velocity" in target:
					target.velocity = vel
			_follow_flow(node_id, 0)

		"NodeMoveAndSlide":
			var target = _resolve_target(node_id, 1)
			if target and target.has_method("move_and_slide"):
				target.move_and_slide()
			_follow_flow(node_id, 0)

		"NodeCallMethod":
			var target = _resolve_target(node_id, 1)
			var method: String = str(props.get("method", ""))
			if target and method and target.has_method(method):
				var arg_count = target.get_method_argument_count(method) if target.has_method("get_method_argument_count") else 0
				# Support up to 3 optional args from data ports 2,3,4
				var a1 = _evaluate_input(node_id, 2)
				var a2 = _evaluate_input(node_id, 3)
				var a3 = _evaluate_input(node_id, 4)
				if a1 != null and a2 != null and a3 != null:
					target.call(method, a1, a2, a3)
				elif a1 != null and a2 != null:
					target.call(method, a1, a2)
				elif a1 != null:
					target.call(method, a1)
				else:
					target.call(method)
			_follow_flow(node_id, 0)

		"NodePrint":
			var value = _evaluate_input(node_id, 1)
			print("[FVS] ", value)
			_follow_flow(node_id, 0)

		"NodeQueueFree":
			var target = _resolve_target(node_id, 1)
			if target is Node:
				target.queue_free()
			_follow_flow(node_id, 0)

		"NodeSetProperty":
			var target = _resolve_target(node_id, 1)
			var value = _evaluate_input(node_id, 2)
			var prop = str(props.get("property", ""))
			if target and prop:
				# Prefer direct property when possible for velocity etc.
				if prop == "velocity" and target is CharacterBody2D and value is Vector2:
					target.velocity = value
				elif prop == "velocity" and target is CharacterBody3D and value is Vector3:
					target.velocity = value
				elif prop == "position" and target is Node2D and value is Vector2:
					target.position = value
				elif prop == "position" and target is Node3D and value is Vector3:
					target.position = value
				else:
					target.set(prop, value)
			_follow_flow(node_id, 0)

		"FunctionDef":
			# Function definitions are structural; body is executed when called
			_follow_flow(node_id, 0)

		"FunctionCall":
			var func_name: String = str(props.get("func_name", ""))
			# Look for a FunctionDef node with matching name and execute its body
			for nd in vs_script.graph_nodes:
				if nd["type"] == "FunctionDef" and str(nd.get("data", {}).get("func_name", "")) == func_name:
					_follow_flow(nd["id"], 0)
					break
			_follow_flow(node_id, 0)

	return null


## Resolve target node: prefer explicit input, fall back to owner (self)
func _resolve_target(node_id: String, port: int) -> Variant:
	var target = _evaluate_input(node_id, port)
	if target == null:
		return _owner_node
	return target


func _evaluate_input(node_id: String, port_index: int) -> Variant:
	for conn in vs_script.graph_connections:
		if conn["to_node"] == node_id and conn["to_port"] == port_index:
			return _evaluate_output(conn["from_node"], conn["from_port"])
	return null


func _evaluate_output(node_id: String, port_index: int) -> Variant:
	var node_data = vs_script.get_node_by_id(node_id)
	if node_data.is_empty():
		return null

	var node_type = node_data.get("type", "")
	var props = node_data.get("data", {})

	match node_type:
		# Event data outputs
		"EventProcess", "EventPhysicsProcess":
			return _context.get("delta", 0.0)
		"EventInput":
			return _context.get("input_event", null)

		# Constants
		"ConstFloat": return float(props.get("value", 0.0))
		"ConstInt": return int(props.get("value", 0))
		"ConstBool": return bool(props.get("value", false))
		"ConstString": return str(props.get("value", ""))
		"ConstVector2":
			return Vector2(float(props.get("x", 0.0)), float(props.get("y", 0.0)))
		"ConstVector3":
			return Vector3(float(props.get("x", 0.0)), float(props.get("y", 0.0)), float(props.get("z", 0.0)))
		"ConstColor":
			return Color(float(props.get("r", 1.0)), float(props.get("g", 1.0)), float(props.get("b", 1.0)), float(props.get("a", 1.0)))

		# Math
		"MathAdd": return _eval_in(node_id, 0) + _eval_in(node_id, 1)
		"MathSubtract": return _eval_in(node_id, 0) - _eval_in(node_id, 1)
		"MathMultiply": return _eval_in(node_id, 0) * _eval_in(node_id, 1)
		"MathDivide":
			var b = _eval_in(node_id, 1)
			return _eval_in(node_id, 0) / b if b != 0 else 0.0
		"MathModulo": return int(_eval_in(node_id, 0)) % int(_eval_in(node_id, 1))
		"MathAbs": return abs(_eval_in(node_id, 0))
		"MathClamp": return clamp(_eval_in(node_id, 0), _eval_in(node_id, 1), _eval_in(node_id, 2))
		"MathLerp": return lerp(_eval_in(node_id, 0), _eval_in(node_id, 1), _eval_in(node_id, 2))
		"MathSin": return sin(_eval_in(node_id, 0))
		"MathCos": return cos(_eval_in(node_id, 0))
		"MathPow": return pow(_eval_in(node_id, 0), _eval_in(node_id, 1))
		"MathSqrt": return sqrt(_eval_in(node_id, 0))
		"MathRandom": return randf()
		"MathRandomRange": return randf_range(_eval_in(node_id, 0), _eval_in(node_id, 1))

		# Logic
		"LogicAnd": return _eval_in(node_id, 0) and _eval_in(node_id, 1)
		"LogicOr": return _eval_in(node_id, 0) or _eval_in(node_id, 1)
		"LogicNot": return not _eval_in(node_id, 0)
		"LogicEqual": return _eval_in(node_id, 0) == _eval_in(node_id, 1)
		"LogicNotEqual": return _eval_in(node_id, 0) != _eval_in(node_id, 1)
		"LogicGreater": return _eval_in(node_id, 0) > _eval_in(node_id, 1)
		"LogicLess": return _eval_in(node_id, 0) < _eval_in(node_id, 1)
		"LogicGreaterEqual": return _eval_in(node_id, 0) >= _eval_in(node_id, 1)
		"LogicLessEqual": return _eval_in(node_id, 0) <= _eval_in(node_id, 1)

		# String
		"StringConcat": return str(_eval_in(node_id, 0)) + str(_eval_in(node_id, 1))
		"StringLength": return len(str(_eval_in(node_id, 0)))
		"StringToInt": return int(str(_eval_in(node_id, 0)))
		"StringToFloat": return float(str(_eval_in(node_id, 0)))
		"StringFormat":
			var fmt: String = str(props.get("format", "%s"))
			return fmt % [_eval_in(node_id, 0)]

		# Variables
		"VarGet", "DeclareVar":
			var var_name: String = str(props.get("var_name", "var"))
			return _context.get(var_name, null)

		# Nodes - FIXED: NodeGetSelf returns the actual owner
		"NodeGetSelf":
			return _owner_node
		"NodeGetNode":
			if _owner_node:
				var path: String = str(props.get("path", "."))
				if path == "." or path.is_empty():
					return _owner_node
				if _owner_node.has_node(path):
					return _owner_node.get_node(path)
			return null
		"NodeGetPosition":
			var target = _eval_in(node_id, 0)
			if target == null:
				target = _owner_node
			if target is Node2D:
				return target.position
			if target is Node3D:
				return target.position
			return Vector2.ZERO
		"NodeGetVelocity":
			var target = _eval_in(node_id, 0)
			if target == null:
				target = _owner_node
			if target and "velocity" in target:
				return target.velocity
			return Vector2.ZERO
		"NodeGetProperty":
			var target = _eval_in(node_id, 0)
			if target == null:
				target = _owner_node
			var prop = str(props.get("property", ""))
			if target and prop:
				return target.get(prop)
			return null
		"NodeIsOnFloor":
			var body = _eval_in(node_id, 0)
			if body == null:
				body = _owner_node
			if body and body.has_method("is_on_floor"):
				return body.is_on_floor()
			return false

		# Vector
		"Vector2Make":
			return Vector2(_eval_in(node_id, 0), _eval_in(node_id, 1))
		"Vector2Break":
			var vec = _eval_in(node_id, 0)
			if vec is Vector2:
				return vec.x if port_index == 0 else vec.y
			return 0.0
		"Vector2Add":
			return _eval_in(node_id, 0) + _eval_in(node_id, 1)
		"Vector2Subtract":
			return _eval_in(node_id, 0) - _eval_in(node_id, 1)
		"Vector2Length":
			var vec = _eval_in(node_id, 0)
			return vec.length() if vec is Vector2 else 0.0
		"Vector2Normalize":
			var vec = _eval_in(node_id, 0)
			return vec.normalized() if vec is Vector2 else Vector2.ZERO
		"Vector2Scale":
			return _eval_in(node_id, 0) * _eval_in(node_id, 1)
		"Vector3Make":
			return Vector3(_eval_in(node_id, 0), _eval_in(node_id, 1), _eval_in(node_id, 2))
		"Vector3Break":
			var vec3 = _eval_in(node_id, 0)
			if vec3 is Vector3:
				if port_index == 0: return vec3.x
				if port_index == 1: return vec3.y
				if port_index == 2: return vec3.z
			return 0.0

		# Input
		"InputIsActionPressed":
			return Input.is_action_pressed(str(props.get("action", "")))
		"InputIsActionJustPressed":
			return Input.is_action_just_pressed(str(props.get("action", "")))
		"InputIsActionJustReleased":
			return Input.is_action_just_released(str(props.get("action", "")))
		"InputGetAxis":
			return Input.get_axis(str(props.get("negative_action", "")), str(props.get("positive_action", "")))
		"InputGetVector":
			return Input.get_vector(
				str(props.get("neg_x", "ui_left")), str(props.get("pos_x", "ui_right")),
				str(props.get("neg_y", "ui_up")), str(props.get("pos_y", "ui_down"))
			)

		# Type / Cast
		"TypeCast":
			return _eval_in(node_id, 0)
		"TypeIs":
			var val = _eval_in(node_id, 0)
			var type_name = str(props.get("type_name", "Node"))
			match type_name:
				"int": return typeof(val) == TYPE_INT
				"float": return typeof(val) == TYPE_FLOAT
				"String": return typeof(val) == TYPE_STRING
				"bool": return typeof(val) == TYPE_BOOL
				"Vector2": return val is Vector2
				"Vector3": return val is Vector3
				"Node": return val is Node
				"Node2D": return val is Node2D
				"CharacterBody2D": return val is CharacterBody2D
				_: return false

		# Utility
		"UtilityReroute": return _eval_in(node_id, 0)
		"GetDelta": return _context.get("delta", 0.0)
		"GetSelf": return _owner_node

	return null


func _eval_in(node_id: String, port: int) -> Variant:
	return _evaluate_input(node_id, port)


func _follow_flow(node_id: String, flow_out_port: int) -> void:
	for conn in vs_script.graph_connections:
		if conn["from_node"] == node_id and conn["from_port"] == flow_out_port:
			_execute_node(conn["to_node"])
			# Support multiple outgoing flows from same port if needed
			# currently first match only (like original)


func _has_connection_to(node_id: String, port: int) -> bool:
	for conn in vs_script.graph_connections:
		if conn["to_node"] == node_id and conn["to_port"] == port:
			return true
	return false


## Generate complete, usable GDScript from the visual graph
func generate_full_code() -> String:
	if not vs_script:
		return "# No FVS script loaded\n"

	var code = "extends %s\n\n" % vs_script.extends_class
	code += "# ============================================================\n"
	code += "# Auto-generated by FVS (Frosty Visual Scripting)\n"
	code += "# DO NOT EDIT MANUALLY — re-export from the FVS editor\n"
	code += "# ============================================================\n\n"

	# Collect declared variables
	var vars_found: Dictionary = {}  # name -> type hint string
	for node_data in vs_script.graph_nodes:
		var t = node_data["type"]
		if t in ["VarSet", "VarGet", "DeclareVar"]:
			var vname = str(node_data.get("data", {}).get("var_name", "var"))
			var vtype = str(node_data.get("data", {}).get("var_type", ""))
			if not vname in vars_found:
				vars_found[vname] = vtype

	for vname in vars_found:
		var hint = vars_found[vname]
		if hint and not hint.is_empty():
			code += "var %s: %s\n" % [vname, hint]
		else:
			code += "var %s\n" % vname

	if not vars_found.is_empty():
		code += "\n"

	# Emit signals declared via EventSignal nodes
	var signals_found: Array[String] = []
	for node_data in vs_script.graph_nodes:
		if node_data["type"] == "EventSignal":
			var sname = str(node_data.get("data", {}).get("signal_name", ""))
			if sname and not sname in signals_found:
				signals_found.append(sname)
				code += "signal %s\n" % sname
	if not signals_found.is_empty():
		code += "\n"

	# Compile event entry points
	var event_map = {
		"EventStart": "_ready",
		"EventProcess": "_process",
		"EventPhysicsProcess": "_physics_process",
		"EventInput": "_input"
	}

	for node_data in vs_script.graph_nodes:
		var t = node_data["type"]
		if t in event_map:
			code += _compile_event(node_data, event_map[t])
			code += "\n"

	# Compile custom functions
	for node_data in vs_script.graph_nodes:
		if node_data["type"] == "FunctionDef":
			code += _compile_function(node_data)
			code += "\n"

	return code


func _compile_event(node_data: Dictionary, func_name: String) -> String:
	var def = FVSNodeDefinitions.get_node_definition(node_data["type"])
	var body = _follow_flow_code(node_data["id"], 0)
	if body.strip_edges().is_empty():
		body = "\tpass"

	match func_name:
		"_ready":
			return "func _ready() -> void:\n%s" % _indent_block(body)
		"_process":
			return "func _process(delta: float) -> void:\n%s" % _indent_block(body)
		"_physics_process":
			return "func _physics_process(delta: float) -> void:\n%s" % _indent_block(body)
		"_input":
			return "func _input(event: InputEvent) -> void:\n%s" % _indent_block(body)
	return "func %s() -> void:\n%s" % [func_name, _indent_block(body)]


func _compile_function(node_data: Dictionary) -> String:
	var props = node_data.get("data", {})
	var fname = str(props.get("func_name", "my_function"))
	var ret_type = str(props.get("return_type", "void"))
	var body = _follow_flow_code(node_data["id"], 0)
	if body.strip_edges().is_empty():
		body = "\tpass"
	return "func %s() -> %s:\n%s" % [fname, ret_type, _indent_block(body)]


func _follow_flow_code(node_id: String, flow_out_port: int) -> String:
	for conn in vs_script.graph_connections:
		if conn["from_node"] == node_id and conn["from_port"] == flow_out_port:
			return _compile_node_code(conn["to_node"])
	return ""


func _compile_node_code(node_id: String) -> String:
	var node_data = vs_script.get_node_by_id(node_id)
	if node_data.is_empty():
		return ""
	var def = FVSNodeDefinitions.get_node_definition(node_data["type"])
	if def.is_empty():
		return ""

	var template: String = str(def.get("code_template", "pass"))
	var props = node_data.get("data", {})

	for key in props:
		template = template.replace("{%s}" % key, str(props[key]))

	# Resolve data inputs
	var inputs: Array = def.get("inputs", [])
	for i in inputs.size():
		var val = _resolve_input_code(node_id, i)
		template = template.replace("{in_%d}" % i, val)

	# Resolve flow outputs
	var outputs: Array = def.get("outputs", [])
	for i in outputs.size():
		if outputs[i].get("port_type") == FVSNodeDefinitions.PortType.FLOW:
			var next = _follow_flow_code(node_id, i)
			if next.is_empty():
				next = "pass"
			template = template.replace("{flow_out_%d}" % i, next)

	# Append continuation if this node has a sequential next flow and template didn't consume all
	return template


func _resolve_input_code(node_id: String, port_index: int) -> String:
	for conn in vs_script.graph_connections:
		if conn["to_node"] == node_id and conn["to_port"] == port_index:
			return _compile_expression(conn["from_node"], conn["from_port"])
	return "null"


func _compile_expression(node_id: String, out_port: int) -> String:
	var node_data = vs_script.get_node_by_id(node_id)
	if node_data.is_empty():
		return "null"
	var def = FVSNodeDefinitions.get_node_definition(node_data["type"])
	if def.is_empty():
		return "null"

	var template: String = str(def.get("code_template", "null"))
	var props = node_data.get("data", {})
	for key in props:
		template = template.replace("{%s}" % key, str(props[key]))

	var inputs: Array = def.get("inputs", [])
	for i in inputs.size():
		if inputs[i].get("port_type") != FVSNodeDefinitions.PortType.FLOW:
			var val = _resolve_input_code(node_id, i)
			template = template.replace("{in_%d}" % i, val)

	# Special handling for multi-output nodes like Vector2Break
	if node_data["type"] == "Vector2Break":
		var vec_expr = _resolve_input_code(node_id, 0)
		return "%s.x" % vec_expr if out_port == 0 else "%s.y" % vec_expr
	if node_data["type"] == "Vector3Break":
		var vec_expr = _resolve_input_code(node_id, 0)
		match out_port:
			0: return "%s.x" % vec_expr
			1: return "%s.y" % vec_expr
			2: return "%s.z" % vec_expr

	return template


func _indent_block(text: String) -> String:
	var lines = text.split("\n")
	var result = ""
	for line in lines:
		if line.strip_edges().is_empty():
			result += "\n"
		else:
			result += "\t" + line + "\n"
	return result.rstrip("\n")
