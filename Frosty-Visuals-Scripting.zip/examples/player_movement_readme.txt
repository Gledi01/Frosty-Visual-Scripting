; FVS Example - Simple Player Movement (CharacterBody2D)
; =====================================================
;
; Recommended graph for a working player controller:
;
; 1. Events > On Physics Process
; 2. Input > Get Vector  (neg_x: ui_left, pos_x: ui_right, neg_y: ui_up, pos_y: ui_down)
; 3. Math > Float Constant  (value: 200.0)   -- speed
; 4. Math > Multiply
; 5. Node > Self
; 6. Node > Set Velocity
; 7. Node > Move And Slide
;
; Connections:
;   OnPhysicsProcess [Flow]  ->  Set Velocity [Flow]
;   GetVector [Direction]    ->  Multiply [A]
;   FloatConst [Value]       ->  Multiply [B]
;   Multiply [Result]        ->  Set Velocity [Velocity]
;   Self                     ->  Set Velocity [Target]
;   Set Velocity [Flow]      ->  Move And Slide [Flow]
;   Self                     ->  Move And Slide [Target]
;
; Setup:
; 1. Enable plugin: Project > Project Settings > Plugins > Frosty Visual Scripting
; 2. Open bottom panel "FVS"
; 3. Build the graph above, Save Visual as res://player_movement.tres
; 4. On your CharacterBody2D, add child node of type FVSScriptRunner
; 5. Assign player_movement.tres to the visual_script property
; 6. Play — character should move with arrow keys / WASD (ui_* actions)
;
; Why movement failed before:
;   NodeGetSelf previously returned get_parent() instead of the owner node.
;   Set Property / velocity also needed a dedicated Set Velocity path.
;   Both are fixed in FVS 2.0.
;
; Export:
;   Click "Export GDScript" to get a complete .gd file you can attach directly.
