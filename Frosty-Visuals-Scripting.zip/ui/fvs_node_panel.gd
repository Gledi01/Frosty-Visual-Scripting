@tool
extends VBoxContainer
class_name FVSNodePanel

## Left sidebar panel showing all available node types organized by category.
## User can click or drag nodes to add them to the graph.

const FVSNodeDefinitions = preload("res://addons/fvs/nodes/fvs_node_definitions.gd")

signal node_selected(node_type: String)

var _search_box: LineEdit
var _tree: Tree
var _root: TreeItem


func _ready() -> void:
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_build_ui()


func _build_ui() -> void:
	# Header
	var header = Label.new()
	header.text = "  Node Library"
	header.add_theme_font_size_override("font_size", 13)
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.2, 0.2, 0.2)
	style.content_margin_left = 6
	style.content_margin_top = 4
	style.content_margin_bottom = 4
	var panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", style)
	panel.add_child(header)
	add_child(panel)

	# Search
	_search_box = LineEdit.new()
	_search_box.placeholder_text = "🔍 Search nodes..."
	_search_box.clear_button_enabled = true
	_search_box.text_changed.connect(_on_search_changed)
	add_child(_search_box)

	# Tree
	_tree = Tree.new()
	_tree.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tree.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tree.hide_root = true
	_tree.custom_minimum_size = Vector2(200, 400)
	_tree.item_activated.connect(_on_item_activated)
	add_child(_tree)

	_populate_tree("")

	# Hint label
	var hint = Label.new()
	hint.text = "Double-click to add node\nor drag to graph"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	hint.add_theme_font_size_override("font_size", 10)
	add_child(hint)


func _populate_tree(filter: String) -> void:
	_tree.clear()
	_root = _tree.create_item()

	var filter_lower = filter.to_lower().strip_edges()

	for category in FVSNodeDefinitions.get_all_categories():
		var nodes = FVSNodeDefinitions.get_nodes_in_category(category)
		var visible_nodes: Array[Dictionary] = []

		for node_def in nodes:
			var title: String = node_def.get("title", node_def["type"])
			var desc: String = node_def.get("description", "")
			if filter_lower.is_empty() \
			or title.to_lower().contains(filter_lower) \
			or desc.to_lower().contains(filter_lower) \
			or category.to_lower().contains(filter_lower):
				visible_nodes.append(node_def)

		if visible_nodes.is_empty():
			continue

		# Category item
		var cat_item = _tree.create_item(_root)
		cat_item.set_text(0, category)
		cat_item.set_selectable(0, false)
		cat_item.set_custom_bg_color(0, Color(0.2, 0.2, 0.2))
		cat_item.set_custom_color(0, Color(0.8, 0.8, 0.8))
		cat_item.collapsed = filter_lower.is_empty() and not category in ["Events", "Flow Control", "Math"]

		for node_def in visible_nodes:
			var item = _tree.create_item(cat_item)
			var title = node_def.get("title", node_def["type"])
			item.set_text(0, "  " + title)
			item.set_metadata(0, node_def["type"])
			item.set_tooltip_text(0, node_def.get("description", node_def["type"]))

			# Color coding
			var col: Color = node_def.get("color", Color(0.5, 0.5, 0.5))
			item.set_custom_color(0, col.lightened(0.3))


func _on_search_changed(text: String) -> void:
	_populate_tree(text)
	if not text.is_empty():
		# Expand all when searching
		var child = _root.get_first_child()
		while child:
			child.collapsed = false
			child = child.get_next()


func _on_item_activated() -> void:
	var selected = _tree.get_selected()
	if selected and selected.get_metadata(0):
		node_selected.emit(selected.get_metadata(0))
