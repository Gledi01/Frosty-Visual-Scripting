@tool
extends Control
class_name FVSGraphEditor

## Main FVS (Frosty Visual Scripting) Editor panel.
## GraphEdit-based visual scripting with Undo/Redo, Load/Save Visual, full GDScript export.

const FVSNodeDefinitions = preload("res://addons/fvs/nodes/fvs_node_definitions.gd")
const FVSGraphNode = preload("res://addons/fvs/ui/fvs_graph_node.gd")
const FVSNodePanel = preload("res://addons/fvs/ui/fvs_node_panel.gd")
const FVSScript = preload("res://addons/fvs/resources/fvs_script.gd")

var _plugin: EditorPlugin
var _current_script: Resource  # FVSScript

# UI
var _graph_edit: GraphEdit
var _toolbar: HBoxContainer
var _node_panel: Control
var _node_panel_container: PanelContainer
var _status_label: Label
var _zoom_label: Label

# State
var _is_modified: bool = false
var _undo_stack: Array[Dictionary] = []
var _redo_stack: Array[Dictionary] = []
const MAX_UNDO := 50


func _ready() -> void:
	_build_ui()
	if not _current_script:
		_current_script = FVSScript.new()
		_rebuild_graph()


func set_plugin(plugin: EditorPlugin) -> void:
	_plugin = plugin


func load_script(script: Resource) -> void:
	_push_undo()
	_current_script = script
	_rebuild_graph()
	_is_modified = false
	if _status_label:
		var name = script.resource_path.get_file() if script.resource_path else script.script_name
		_status_label.text = "Editing: %s" % name


func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var main_vbox = VBoxContainer.new()
	main_vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(main_vbox)

	_build_toolbar(main_vbox)

	var hsplit = HSplitContainer.new()
	hsplit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hsplit.split_offset = 220
	main_vbox.add_child(hsplit)

	_node_panel_container = PanelContainer.new()
	_node_panel_container.custom_minimum_size = Vector2(220, 0)
	hsplit.add_child(_node_panel_container)

	var node_panel_scroll = ScrollContainer.new()
	node_panel_scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	node_panel_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_node_panel_container.add_child(node_panel_scroll)

	_node_panel = FVSNodePanel.new()
	_node_panel.node_selected.connect(_on_add_node_requested)
	node_panel_scroll.add_child(_node_panel)

	_graph_edit = GraphEdit.new()
	_graph_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_graph_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_graph_edit.right_disconnects = true
	_graph_edit.snapping_enabled = true
	_graph_edit.snapping_distance = 20
	_graph_edit.minimap_enabled = true
	_graph_edit.minimap_size = Vector2(200, 150)
	hsplit.add_child(_graph_edit)

	_graph_edit.connection_request.connect(_on_connection_request)
	_graph_edit.disconnection_request.connect(_on_disconnection_request)
	_graph_edit.node_selected.connect(_on_graph_node_selected)
	_graph_edit.delete_nodes_request.connect(_on_delete_nodes_request)
	_graph_edit.gui_input.connect(_on_graph_gui_input)
	_graph_edit.scroll_offset_changed.connect(_on_scroll_offset_changed)
	_graph_edit.zoom_level_changed.connect(_on_zoom_changed)


func _build_toolbar(parent: Control) -> void:
	_toolbar = HBoxContainer.new()
	_toolbar.custom_minimum_size.y = 36
	parent.add_child(_toolbar)

	_add_btn("New", _on_new_script)
	_add_btn("Load Visual", _on_load_visual)
	_add_btn("Save Visual", _on_save_script)
	_add_btn("Save As...", _on_save_as)
	_toolbar.add_child(VSeparator.new())
	_add_btn("Undo", _on_undo)
	_add_btn("Redo", _on_redo)
	_toolbar.add_child(VSeparator.new())
	_add_btn("Export GDScript", _on_compile_script)
	_toolbar.add_child(VSeparator.new())
	_add_btn("Clear", _on_clear_graph)
	_add_btn("Arrange", _on_arrange_nodes)

	_status_label = Label.new()
	_status_label.text = "No script loaded"
	_status_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_toolbar.add_child(_status_label)

	_zoom_label = Label.new()
	_zoom_label.text = "100%"
	_toolbar.add_child(_zoom_label)


func _add_btn(text: String, callback: Callable) -> void:
	var btn = Button.new()
	btn.text = "  " + text + "  "
	btn.pressed.connect(callback)
	_toolbar.add_child(btn)


# ── Undo / Redo ──

func _push_undo() -> void:
	if not _current_script:
		return
	var state = _current_script.duplicate_graph()
	_undo_stack.append(state)
	if _undo_stack.size() > MAX_UNDO:
		_undo_stack.pop_front()
	_redo_stack.clear()


func _on_undo() -> void:
	if _undo_stack.is_empty() or not _current_script:
		_status_label.text = "Nothing to undo"
		return
	_redo_stack.append(_current_script.duplicate_graph())
	var state = _undo_stack.pop_back()
	_current_script.restore_graph(state)
	_rebuild_graph()
	_is_modified = true
	_status_label.text = "Undo (%d left)" % _undo_stack.size()


func _on_redo() -> void:
	if _redo_stack.is_empty() or not _current_script:
		_status_label.text = "Nothing to redo"
		return
	_undo_stack.append(_current_script.duplicate_graph())
	var state = _redo_stack.pop_back()
	_current_script.restore_graph(state)
	_rebuild_graph()
	_is_modified = true
	_status_label.text = "Redo (%d left)" % _redo_stack.size()


# ── Graph rebuild ──

func _rebuild_graph() -> void:
	if not _graph_edit or not _current_script:
		return

	for child in _graph_edit.get_children():
		if child is GraphNode:
			child.queue_free()
	_graph_edit.clear_connections()

	await get_tree().process_frame

	for node_data in _current_script.graph_nodes:
		_create_graph_node(node_data)

	await get_tree().process_frame

	for conn in _current_script.graph_connections:
		_graph_edit.connect_node(
			conn["from_node"], conn["from_port"],
			conn["to_node"], conn["to_port"]
		)

	if _current_script.graph_offset != Vector2.ZERO:
		_graph_edit.scroll_offset = _current_script.graph_offset
	_graph_edit.zoom = _current_script.graph_zoom


func _create_graph_node(node_data: Dictionary) -> GraphNode:
	var node_type = node_data.get("type", "")
	var definition = FVSNodeDefinitions.get_node_definition(node_type)
	if definition.is_empty():
		push_warning("FVS: Unknown node type: %s" % node_type)
		return null

	var graph_node = FVSGraphNode.new()
	graph_node.name = node_data["id"]
	graph_node.setup(node_data, definition)
	graph_node.position_offset = node_data.get("position", Vector2(100, 100))
	graph_node.node_data_changed.connect(_on_node_data_changed.bind(node_data["id"]))
	_graph_edit.add_child(graph_node)
	return graph_node


func _spawn_node_at(node_type: String, position: Vector2) -> void:
	_push_undo()
	var definition = FVSNodeDefinitions.get_node_definition(node_type)
	if definition.is_empty():
		return

	var node_id = "%s_%d" % [node_type.to_lower(), Time.get_ticks_msec()]
	var node_data = {
		"id": node_id,
		"type": node_type,
		"position": position,
		"data": {}
	}
	if definition.has("properties"):
		for prop in definition["properties"]:
			node_data["data"][prop["name"]] = prop.get("default", null)

	_current_script.add_node(node_data)
	var gn = _create_graph_node(node_data)
	if gn:
		gn.position_offset = position
	_is_modified = true


# ── Signals ──

func _on_connection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	_push_undo()
	_graph_edit.connect_node(from_node, from_port, to_node, to_port)
	_current_script.add_connection(from_node, from_port, to_node, to_port)
	_is_modified = true


func _on_disconnection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	_push_undo()
	_graph_edit.disconnect_node(from_node, from_port, to_node, to_port)
	_current_script.remove_connection(from_node, from_port, to_node, to_port)
	_is_modified = true


func _on_graph_node_selected(_node: Node) -> void:
	pass


func _on_delete_nodes_request(nodes: Array[StringName]) -> void:
	_push_undo()
	for node_name in nodes:
		var node = _graph_edit.get_node(NodePath(node_name))
		if node:
			_current_script.remove_node(node_name)
			node.queue_free()
	_is_modified = true


func _on_graph_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
			_show_context_menu(event.position)


func _on_scroll_offset_changed(offset: Vector2) -> void:
	if _current_script:
		_current_script.graph_offset = offset


func _on_zoom_changed(zoom: float) -> void:
	if _current_script:
		_current_script.graph_zoom = zoom
	if _zoom_label:
		_zoom_label.text = "%d%%" % int(zoom * 100)


func _on_node_data_changed(key: String, value: Variant, node_id: String) -> void:
	_push_undo()
	_current_script.update_node_data(node_id, key, value)
	_is_modified = true


func _on_add_node_requested(node_type: String) -> void:
	var center = _graph_edit.scroll_offset + _graph_edit.size * 0.5
	var pos = center / _graph_edit.zoom
	_spawn_node_at(node_type, pos)


# ── Context menu ──

func _show_context_menu(at_position: Vector2) -> void:
	var popup = PopupMenu.new()
	popup.add_item("Add Node...", 0)
	popup.add_separator()
	popup.add_item("Select All", 1)
	popup.add_item("Arrange Nodes", 2)
	popup.add_separator()
	popup.add_item("Clear Graph", 3)
	add_child(popup)
	popup.popup(Rect2(get_global_position() + at_position, Vector2.ZERO))
	popup.id_pressed.connect(func(id: int):
		match id:
			0: _show_add_node_dialog(at_position)
			1: _select_all_nodes()
			2: _on_arrange_nodes()
			3: _on_clear_graph()
		popup.queue_free()
	)
	popup.popup_hide.connect(popup.queue_free)


func _show_add_node_dialog(at_position: Vector2) -> void:
	var dialog = Window.new()
	dialog.title = "Add FVS Node"
	dialog.size = Vector2(420, 520)
	dialog.transient = true
	dialog.exclusive = true
	dialog.close_requested.connect(dialog.queue_free)
	add_child(dialog)

	var vbox = VBoxContainer.new()
	vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 4)
	dialog.add_child(vbox)

	var search = LineEdit.new()
	search.placeholder_text = "Search nodes..."
	vbox.add_child(search)

	var tree = Tree.new()
	tree.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tree.hide_root = true
	vbox.add_child(tree)

	var root = tree.create_item()
	for cat in FVSNodeDefinitions.get_all_categories():
		var cat_item = tree.create_item(root)
		cat_item.set_text(0, cat)
		cat_item.set_selectable(0, false)
		for node_def in FVSNodeDefinitions.get_nodes_in_category(cat):
			var item = tree.create_item(cat_item)
			item.set_text(0, "  " + node_def.get("title", node_def["type"]))
			item.set_metadata(0, node_def["type"])
			item.set_tooltip_text(0, node_def.get("description", ""))

	var graph_pos = (at_position + _graph_edit.scroll_offset) / _graph_edit.zoom

	tree.item_activated.connect(func():
		var selected = tree.get_selected()
		if selected and selected.get_metadata(0):
			_spawn_node_at(selected.get_metadata(0), graph_pos)
			dialog.queue_free()
	)

	search.text_changed.connect(func(text: String):
		_filter_tree(tree, root, text.to_lower())
	)

	var btn_close = Button.new()
	btn_close.text = "Close"
	btn_close.pressed.connect(dialog.queue_free)
	vbox.add_child(btn_close)

	dialog.popup_centered()
	search.grab_focus()


func _filter_tree(tree: Tree, root: TreeItem, filter: String) -> void:
	for cat_item in root.get_children():
		var has_visible = false
		for item in cat_item.get_children():
			var visible = filter.is_empty() or item.get_text(0).to_lower().contains(filter)
			item.visible = visible
			if visible:
				has_visible = true
		cat_item.visible = has_visible


func _select_all_nodes() -> void:
	for child in _graph_edit.get_children():
		if child is GraphNode:
			child.selected = true


# ── Toolbar actions ──

func _on_new_script() -> void:
	_push_undo()
	_current_script = FVSScript.new()
	_rebuild_graph()
	_status_label.text = "New (unsaved) FVS script"
	_is_modified = false


func _on_load_visual() -> void:
	var dialog = EditorFileDialog.new()
	dialog.file_mode = EditorFileDialog.FILE_MODE_OPEN_FILE
	dialog.access = EditorFileDialog.ACCESS_RESOURCES
	dialog.filters = PackedStringArray(["*.tres ; FVS Visual Script", "*.res ; Resource"])
	dialog.title = "Load FVS Visual Script"
	dialog.close_requested.connect(dialog.queue_free)
	add_child(dialog)
	dialog.file_selected.connect(func(path: String):
		var res = load(path)
		if res and res is Resource:
			# Accept both FVSScript and generic Resource with graph_nodes
			if "graph_nodes" in res:
				_push_undo()
				_current_script = res
				_rebuild_graph()
				_is_modified = false
				_status_label.text = "Loaded: %s" % path.get_file()
			else:
				_status_label.text = "Not a valid FVS script: %s" % path.get_file()
		dialog.queue_free()
	)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered_ratio(0.7)


func _on_save_script() -> void:
	if not _current_script:
		return
	if _current_script.resource_path.is_empty():
		_on_save_as()
	else:
		ResourceSaver.save(_current_script)
		_is_modified = false
		_status_label.text = "Saved: %s" % _current_script.resource_path.get_file()


func _on_save_as() -> void:
	var dialog = EditorFileDialog.new()
	dialog.file_mode = EditorFileDialog.FILE_MODE_SAVE_FILE
	dialog.access = EditorFileDialog.ACCESS_RESOURCES
	dialog.filters = PackedStringArray(["*.tres ; FVS Visual Script"])
	dialog.title = "Save FVS Visual Script"
	dialog.close_requested.connect(dialog.queue_free)
	add_child(dialog)
	dialog.file_selected.connect(func(path: String):
		_current_script.resource_path = path
		ResourceSaver.save(_current_script, path)
		_is_modified = false
		_status_label.text = "Saved: %s" % path.get_file()
		dialog.queue_free()
	)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered_ratio(0.7)


func _on_compile_script() -> void:
	if not _current_script:
		return

	var code = ""
	if _current_script.has_method("compile_to_gdscript"):
		code = _current_script.compile_to_gdscript()
	else:
		var executor = load("res://addons/fvs/resources/fvs_script_executor.gd").new()
		executor.vs_script = _current_script
		code = executor.generate_full_code()

	var dialog = Window.new()
	dialog.title = "FVS → GDScript Export"
	dialog.size = Vector2(700, 560)
	dialog.transient = true
	dialog.close_requested.connect(dialog.queue_free)
	add_child(dialog)

	var vbox = VBoxContainer.new()
	vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vbox.add_theme_constant_override("separation", 6)
	dialog.add_child(vbox)

	var text_edit = TextEdit.new()
	text_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text_edit.text = code
	text_edit.editable = true
	vbox.add_child(text_edit)

	var hbox = HBoxContainer.new()
	vbox.add_child(hbox)

	var btn_copy = Button.new()
	btn_copy.text = "Copy to Clipboard"
	btn_copy.pressed.connect(func():
		DisplayServer.clipboard_set(text_edit.text)
		_status_label.text = "GDScript copied to clipboard"
	)
	hbox.add_child(btn_copy)

	var btn_save = Button.new()
	btn_save.text = "Save as .gd"
	btn_save.pressed.connect(func():
		var save_dlg = EditorFileDialog.new()
		save_dlg.file_mode = EditorFileDialog.FILE_MODE_SAVE_FILE
		save_dlg.access = EditorFileDialog.ACCESS_RESOURCES
		save_dlg.filters = PackedStringArray(["*.gd ; GDScript"])
		save_dlg.title = "Save Exported GDScript"
		save_dlg.close_requested.connect(save_dlg.queue_free)
		add_child(save_dlg)
		save_dlg.file_selected.connect(func(path: String):
			var f = FileAccess.open(path, FileAccess.WRITE)
			if f:
				f.store_string(text_edit.text)
				f.close()
				_status_label.text = "Exported: %s" % path.get_file()
			save_dlg.queue_free()
		)
		save_dlg.canceled.connect(save_dlg.queue_free)
		save_dlg.popup_centered_ratio(0.6)
	)
	hbox.add_child(btn_save)

	var btn_close = Button.new()
	btn_close.text = "Close"
	btn_close.pressed.connect(dialog.queue_free)
	hbox.add_child(btn_close)

	dialog.popup_centered()


func _on_clear_graph() -> void:
	var confirm = AcceptDialog.new()
	confirm.title = "Clear Graph"
	confirm.dialog_text = "Clear all nodes and connections? You can Undo afterwards."
	confirm.add_cancel_button("Cancel")
	confirm.close_requested.connect(confirm.queue_free)
	add_child(confirm)
	confirm.confirmed.connect(func():
		_push_undo()
		for child in _graph_edit.get_children():
			if child is GraphNode:
				child.queue_free()
		_graph_edit.clear_connections()
		if _current_script:
			_current_script.graph_nodes.clear()
			_current_script.graph_connections.clear()
			_current_script.emit_changed()
		_is_modified = true
		confirm.queue_free()
	)
	confirm.canceled.connect(confirm.queue_free)
	confirm.popup_centered()


func _on_arrange_nodes() -> void:
	if _graph_edit:
		_graph_edit.arrange_nodes()


func _process(_delta: float) -> void:
	if not _current_script or not _graph_edit:
		return
	for child in _graph_edit.get_children():
		if child is GraphNode:
			var node_id = child.name
			var stored = _current_script.get_node_by_id(node_id)
			if not stored.is_empty():
				if stored.get("position", Vector2.ZERO) != child.position_offset:
					_current_script.update_node_position(node_id, child.position_offset)
