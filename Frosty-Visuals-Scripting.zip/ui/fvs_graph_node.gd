@tool
extends GraphNode
class_name FVSGraphNode

## Visual representation of a single VS node in the graph editor.
## Builds its UI from node definition data.

const FVSNodeDefinitions = preload("res://addons/fvs/nodes/fvs_node_definitions.gd")

signal node_data_changed(key: String, value: Variant)

var _node_data: Dictionary
var _definition: Dictionary
var _property_controls: Dictionary = {}


func setup(node_data: Dictionary, definition: Dictionary) -> void:
	_node_data = node_data
	_definition = definition

	title = definition.get("title", node_data.get("type", "Unknown"))

	# Node color via titlebar
	var node_color: Color = definition.get("color", Color(0.3, 0.3, 0.3))
	_apply_title_color(node_color)

	# Build slots
	_build_content()
	_apply_slots()

	# Tooltip
	tooltip_text = definition.get("description", "")


func _apply_title_color(color: Color) -> void:
	# Style the title bar
	var style = StyleBoxFlat.new()
	style.bg_color = color.darkened(0.2)
	style.corner_radius_top_left = 6
	style.corner_radius_top_right = 6
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 4
	style.content_margin_bottom = 4
	add_theme_stylebox_override("titlebar", style)

	var style_selected = style.duplicate()
	style_selected.bg_color = color
	add_theme_stylebox_override("titlebar_selected", style_selected)

	var panel_style = StyleBoxFlat.new()
	panel_style.bg_color = Color(0.18, 0.18, 0.18)
	panel_style.border_color = color.darkened(0.3)
	panel_style.border_width_left = 1
	panel_style.border_width_right = 1
	panel_style.border_width_bottom = 1
	panel_style.corner_radius_bottom_left = 6
	panel_style.corner_radius_bottom_right = 6
	panel_style.content_margin_left = 6
	panel_style.content_margin_right = 6
	panel_style.content_margin_top = 6
	panel_style.content_margin_bottom = 6
	add_theme_stylebox_override("panel", panel_style)

	var panel_selected_style = panel_style.duplicate()
	panel_selected_style.border_color = color
	panel_selected_style.border_width_left = 2
	panel_selected_style.border_width_right = 2
	panel_selected_style.border_width_bottom = 2
	add_theme_stylebox_override("panel_selected", panel_selected_style)


func _build_content() -> void:
	# Clear existing children
	for child in get_children():
		child.queue_free()

	var inputs: Array = _definition.get("inputs", [])
	var outputs: Array = _definition.get("outputs", [])
	var properties: Array = _definition.get("properties", [])

	# Calculate max rows needed
	var max_rows = max(max(inputs.size(), outputs.size()), 1)

	# Add property editors first
	if not properties.is_empty():
		var prop_container = VBoxContainer.new()
		prop_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		for prop in properties:
			var row = _build_property_row(prop)
			prop_container.add_child(row)
		add_child(prop_container)

	# Build rows for inputs/outputs
	for i in max_rows:
		var row = HBoxContainer.new()
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.custom_minimum_size.x = 180

		# Input label
		var input_label = Label.new()
		input_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if i < inputs.size():
			input_label.text = inputs[i]["name"]
			input_label.add_theme_color_override(
				"font_color",
				FVSNodeDefinitions.PORT_COLORS.get(inputs[i]["port_type"], Color.WHITE)
			)
		row.add_child(input_label)

		# Output label
		var output_label = Label.new()
		output_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		output_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		if i < outputs.size():
			output_label.text = outputs[i]["name"]
			output_label.add_theme_color_override(
				"font_color",
				FVSNodeDefinitions.PORT_COLORS.get(outputs[i]["port_type"], Color.WHITE)
			)
		row.add_child(output_label)

		add_child(row)


func _build_property_row(prop: Dictionary) -> Control:
	var row = HBoxContainer.new()
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	var label = Label.new()
	label.text = prop["name"].capitalize() + ":"
	label.custom_minimum_size.x = 60
	row.add_child(label)

	var current_value = _node_data.get("data", {}).get(prop["name"], prop.get("default", null))

	match prop["type"]:
		"string":
			var edit = LineEdit.new()
			edit.text = str(current_value) if current_value != null else ""
			edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			edit.text_changed.connect(func(val: String):
				node_data_changed.emit(prop["name"], val)
			)
			row.add_child(edit)
			_property_controls[prop["name"]] = edit

		"float":
			var spin = SpinBox.new()
			spin.min_value = -99999.0
			spin.max_value = 99999.0
			spin.step = 0.01
			spin.allow_lesser = true
			spin.allow_greater = true
			spin.value = float(current_value) if current_value != null else 0.0
			spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			spin.value_changed.connect(func(val: float):
				node_data_changed.emit(prop["name"], val)
			)
			row.add_child(spin)
			_property_controls[prop["name"]] = spin

		"int":
			var spin = SpinBox.new()
			spin.min_value = -99999
			spin.max_value = 99999
			spin.step = 1
			spin.allow_lesser = true
			spin.allow_greater = true
			spin.value = int(current_value) if current_value != null else 0
			spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			spin.value_changed.connect(func(val: float):
				node_data_changed.emit(prop["name"], int(val))
			)
			row.add_child(spin)
			_property_controls[prop["name"]] = spin

		"bool":
			var check = CheckBox.new()
			check.button_pressed = bool(current_value) if current_value != null else false
			check.toggled.connect(func(val: bool):
				node_data_changed.emit(prop["name"], val)
			)
			row.add_child(check)
			_property_controls[prop["name"]] = check

		"color":
			var color_picker = ColorPickerButton.new()
			if current_value is Color:
				color_picker.color = current_value
			color_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			color_picker.color_changed.connect(func(val: Color):
				node_data_changed.emit(prop["name"], val)
			)
			row.add_child(color_picker)
			_property_controls[prop["name"]] = color_picker

	return row


func _apply_slots() -> void:
	var inputs: Array = _definition.get("inputs", [])
	var outputs: Array = _definition.get("outputs", [])
	var properties: Array = _definition.get("properties", [])

	# Clear all slots first
	clear_all_slots()

	# Properties take up slots but have no ports
	var slot_offset = 0
	if not properties.is_empty():
		slot_offset = 1  # property container is one child

	var max_rows = max(inputs.size(), outputs.size())

	for i in max_rows:
		var slot_idx = i + slot_offset

		var has_input = i < inputs.size()
		var has_output = i < outputs.size()

		var in_type = 0
		var in_color = Color.WHITE
		var out_type = 0
		var out_color = Color.WHITE

		if has_input:
			in_type = _port_type_to_slot_type(inputs[i]["port_type"])
			in_color = FVSNodeDefinitions.PORT_COLORS.get(inputs[i]["port_type"], Color.WHITE)

		if has_output:
			out_type = _port_type_to_slot_type(outputs[i]["port_type"])
			out_color = FVSNodeDefinitions.PORT_COLORS.get(outputs[i]["port_type"], Color.WHITE)

		set_slot(
			slot_idx,
			has_input, in_type, in_color,
			has_output, out_type, out_color
		)


func _port_type_to_slot_type(port_type: int) -> int:
	# GraphEdit hanya connect port jika type integer-nya SAMA.
	# Solusi: FLOW = type 1 (khusus eksekusi)
	#         Semua DATA port = type 0 (bisa saling connect)
	# Warna tetap berbeda untuk memberi info visual ke user.
	if port_type == 0:  # PortType.FLOW
		return 1  # Flow port — hanya connect ke sesama flow
	return 0  # Semua data port (bool, int, float, string, vector, ANY, dll) = type 0
