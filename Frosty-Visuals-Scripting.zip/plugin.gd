@tool
extends EditorPlugin

const FVSGraphEditor = preload("res://addons/fvs/ui/fvs_graph_editor.gd")
const FVSScript = preload("res://addons/fvs/resources/fvs_script.gd")

var _editor_panel: Control
var _editor_button: Button


func _enter_tree() -> void:
	add_custom_type(
		"FVSScript",
		"Resource",
		preload("res://addons/fvs/resources/fvs_script.gd"),
		preload("res://addons/fvs/icons/fvs_icon.svg")
	)
	add_custom_type(
		"FVSScriptRunner",
		"Node",
		preload("res://addons/fvs/resources/fvs_script_runner.gd"),
		preload("res://addons/fvs/icons/fvs_icon.svg")
	)

	_editor_panel = FVSGraphEditor.new()
	_editor_panel.set_plugin(self)
	_editor_button = add_control_to_bottom_panel(_editor_panel, "FVS")


func _exit_tree() -> void:
	if _editor_panel:
		remove_control_from_bottom_panel(_editor_panel)
		_editor_panel.queue_free()
		_editor_panel = null
	remove_custom_type("FVSScript")
	remove_custom_type("FVSScriptRunner")


func handles(object: Object) -> bool:
	return object is FVSScript


func edit(object: Object) -> void:
	if object is FVSScript and _editor_panel:
		make_bottom_panel_item_visible(_editor_panel)
		_editor_panel.load_script(object)


func get_plugin_name() -> String:
	return "Frosty Visual Scripting"


func get_plugin_icon() -> Texture2D:
	var icon_path = "res://addons/fvs/icons/fvs_icon.svg"
	if ResourceLoader.exists(icon_path):
		return load(icon_path)
	return get_editor_interface().get_base_control().get_theme_icon("Script", "EditorIcons")
