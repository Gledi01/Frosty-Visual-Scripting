@tool
extends RefCounted
class_name FVSNodeDefinitions

## Defines all available node types in the visual scripting system.
## Each node has: category, color, inputs, outputs, and code generation logic.

enum PortType {
	FLOW,       # Execution flow (white)
	BOOL,       # Boolean (yellow)
	INT,        # Integer (green)
	FLOAT,      # Float (blue)
	STRING,     # String (orange)
	VECTOR2,    # Vector2 (purple)
	VECTOR3,    # Vector3 (pink)
	COLOR,      # Color (red)
	OBJECT,     # Object reference (brown)
	ANY,        # Any type (grey)
}

const PORT_COLORS = {
	PortType.FLOW: Color(0.9, 0.9, 0.9),
	PortType.BOOL: Color(0.9, 0.8, 0.1),
	PortType.INT: Color(0.2, 0.8, 0.3),
	PortType.FLOAT: Color(0.2, 0.5, 0.9),
	PortType.STRING: Color(0.9, 0.5, 0.1),
	PortType.VECTOR2: Color(0.7, 0.2, 0.9),
	PortType.VECTOR3: Color(0.9, 0.2, 0.7),
	PortType.COLOR: Color(0.9, 0.2, 0.2),
	PortType.OBJECT: Color(0.6, 0.4, 0.2),
	PortType.ANY: Color(0.6, 0.6, 0.6),
}

static func get_all_categories() -> Array[String]:
	return ["Events", "Flow Control", "Math", "Logic", "String", "Variables", "Node", "Vector", "Input", "Utility", "Types", "Functions"]


static func get_nodes_in_category(category: String) -> Array[Dictionary]:
	match category:
		"Events":
			return _get_event_nodes()
		"Flow Control":
			return _get_flow_nodes()
		"Math":
			return _get_math_nodes()
		"Logic":
			return _get_logic_nodes()
		"String":
			return _get_string_nodes()
		"Variables":
			return _get_variable_nodes()
		"Node":
			return _get_node_nodes()
		"Vector":
			return _get_vector_nodes()
		"Input":
			return _get_input_nodes()
		"Utility":
			return _get_utility_nodes()
		"Types":
			return _get_type_nodes()
		"Functions":
			return _get_function_nodes()
	return []


static func get_node_definition(type: String) -> Dictionary:
	for cat in get_all_categories():
		for node_def in get_nodes_in_category(cat):
			if node_def["type"] == type:
				return node_def
	return {}


# ─────────────────────────────────────────────
# EVENT NODES
# ─────────────────────────────────────────────
static func _get_event_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "EventStart",
			"title": "On Start",
			"category": "Events",
			"color": Color(0.2, 0.6, 0.2),
			"description": "Triggered when the scene starts (_ready).",
			"inputs": [],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW}
			],
			"code_template": "func _ready():\n\t{flow_out_0}"
		},
		{
			"type": "EventProcess",
			"title": "On Process",
			"category": "Events",
			"color": Color(0.2, 0.5, 0.2),
			"description": "Triggered every frame (_process).",
			"inputs": [],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Delta", "port_type": PortType.FLOAT}
			],
			"code_template": "func _process(delta: float):\n\t{flow_out_0}"
		},
		{
			"type": "EventPhysicsProcess",
			"title": "On Physics Process",
			"category": "Events",
			"color": Color(0.2, 0.5, 0.3),
			"description": "Triggered every physics frame.",
			"inputs": [],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Delta", "port_type": PortType.FLOAT}
			],
			"code_template": "func _physics_process(delta: float):\n\t{flow_out_0}"
		},
		{
			"type": "EventInput",
			"title": "On Input",
			"category": "Events",
			"color": Color(0.2, 0.4, 0.6),
			"description": "Triggered on input events.",
			"inputs": [],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Event", "port_type": PortType.OBJECT}
			],
			"code_template": "func _input(event: InputEvent):\n\t{flow_out_0}"
		},
		{
			"type": "EventSignal",
			"title": "On Signal",
			"category": "Events",
			"color": Color(0.5, 0.3, 0.6),
			"description": "Emits a custom signal.",
			"properties": [
				{"name": "signal_name", "type": "string", "default": "my_signal"}
			],
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW}
			],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW}
			],
			"code_template": "emit_signal(\"{signal_name}\")"
		},
	]


# ─────────────────────────────────────────────
# FLOW CONTROL NODES
# ─────────────────────────────────────────────
static func _get_flow_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "FlowBranch",
			"title": "Branch (If)",
			"category": "Flow Control",
			"color": Color(0.7, 0.5, 0.1),
			"description": "Branches execution based on a condition.",
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Condition", "port_type": PortType.BOOL}
			],
			"outputs": [
				{"name": "True", "port_type": PortType.FLOW},
				{"name": "False", "port_type": PortType.FLOW}
			],
			"code_template": "if {in_1}:\n\t{flow_out_0}\nelse:\n\t{flow_out_1}"
		},
		{
			"type": "FlowWhile",
			"title": "While Loop",
			"category": "Flow Control",
			"color": Color(0.7, 0.4, 0.1),
			"description": "Repeats while condition is true.",
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Condition", "port_type": PortType.BOOL}
			],
			"outputs": [
				{"name": "Loop Body", "port_type": PortType.FLOW},
				{"name": "Done", "port_type": PortType.FLOW}
			],
			"code_template": "while {in_1}:\n\t{flow_out_0}\n{flow_out_1}"
		},
		{
			"type": "FlowForRange",
			"title": "For Range",
			"category": "Flow Control",
			"color": Color(0.6, 0.4, 0.1),
			"description": "Iterates over a range of integers.",
			"properties": [
				{"name": "start", "type": "int", "default": 0},
				{"name": "end", "type": "int", "default": 10},
				{"name": "step", "type": "int", "default": 1}
			],
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Start", "port_type": PortType.INT},
				{"name": "End", "port_type": PortType.INT}
			],
			"outputs": [
				{"name": "Loop Body", "port_type": PortType.FLOW},
				{"name": "Index", "port_type": PortType.INT},
				{"name": "Done", "port_type": PortType.FLOW}
			],
			"code_template": "for _i in range({in_1}, {in_2}):\n\t{flow_out_0}\n{flow_out_2}"
		},
		{
			"type": "FlowBreak",
			"title": "Break",
			"category": "Flow Control",
			"color": Color(0.8, 0.2, 0.2),
			"description": "Break out of a loop.",
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW}
			],
			"outputs": [],
			"code_template": "break"
		},
		{
			"type": "FlowReturn",
			"title": "Return",
			"category": "Flow Control",
			"color": Color(0.8, 0.2, 0.2),
			"description": "Return from current function.",
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Value", "port_type": PortType.ANY}
			],
			"outputs": [],
			"code_template": "return {in_1}"
		},
		{
			"type": "FlowSequence",
			"title": "Sequence",
			"category": "Flow Control",
			"color": Color(0.4, 0.4, 0.6),
			"description": "Execute multiple flows in order.",
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW}
			],
			"outputs": [
				{"name": "Step 1", "port_type": PortType.FLOW},
				{"name": "Step 2", "port_type": PortType.FLOW},
				{"name": "Step 3", "port_type": PortType.FLOW}
			],
			"code_template": "{flow_out_0}\n{flow_out_1}\n{flow_out_2}"
		},
	]


# ─────────────────────────────────────────────
# MATH NODES
# ─────────────────────────────────────────────
static func _get_math_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "MathAdd",
			"title": "Add",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Add two numbers.",
			"inputs": [
				{"name": "A", "port_type": PortType.FLOAT},
				{"name": "B", "port_type": PortType.FLOAT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.FLOAT}
			],
			"code_template": "{in_0} + {in_1}"
		},
		{
			"type": "MathSubtract",
			"title": "Subtract",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Subtract two numbers.",
			"inputs": [
				{"name": "A", "port_type": PortType.FLOAT},
				{"name": "B", "port_type": PortType.FLOAT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.FLOAT}
			],
			"code_template": "{in_0} - {in_1}"
		},
		{
			"type": "MathMultiply",
			"title": "Multiply",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Multiply two numbers.",
			"inputs": [
				{"name": "A", "port_type": PortType.FLOAT},
				{"name": "B", "port_type": PortType.FLOAT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.FLOAT}
			],
			"code_template": "{in_0} * {in_1}"
		},
		{
			"type": "MathDivide",
			"title": "Divide",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Divide two numbers.",
			"inputs": [
				{"name": "A", "port_type": PortType.FLOAT},
				{"name": "B", "port_type": PortType.FLOAT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.FLOAT}
			],
			"code_template": "{in_0} / {in_1}"
		},
		{
			"type": "MathModulo",
			"title": "Modulo",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Remainder of division.",
			"inputs": [
				{"name": "A", "port_type": PortType.INT},
				{"name": "B", "port_type": PortType.INT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.INT}
			],
			"code_template": "{in_0} % {in_1}"
		},
		{
			"type": "MathAbs",
			"title": "Absolute Value",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Absolute value of a number.",
			"inputs": [
				{"name": "Value", "port_type": PortType.FLOAT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.FLOAT}
			],
			"code_template": "abs({in_0})"
		},
		{
			"type": "MathClamp",
			"title": "Clamp",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Clamp value between min and max.",
			"inputs": [
				{"name": "Value", "port_type": PortType.FLOAT},
				{"name": "Min", "port_type": PortType.FLOAT},
				{"name": "Max", "port_type": PortType.FLOAT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.FLOAT}
			],
			"code_template": "clamp({in_0}, {in_1}, {in_2})"
		},
		{
			"type": "MathLerp",
			"title": "Lerp",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"description": "Linear interpolation between two values.",
			"inputs": [
				{"name": "From", "port_type": PortType.FLOAT},
				{"name": "To", "port_type": PortType.FLOAT},
				{"name": "Weight", "port_type": PortType.FLOAT}
			],
			"outputs": [
				{"name": "Result", "port_type": PortType.FLOAT}
			],
			"code_template": "lerp({in_0}, {in_1}, {in_2})"
		},
		{
			"type": "MathSin",
			"title": "Sin",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"inputs": [{"name": "Angle (rad)", "port_type": PortType.FLOAT}],
			"outputs": [{"name": "Result", "port_type": PortType.FLOAT}],
			"code_template": "sin({in_0})"
		},
		{
			"type": "MathCos",
			"title": "Cos",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"inputs": [{"name": "Angle (rad)", "port_type": PortType.FLOAT}],
			"outputs": [{"name": "Result", "port_type": PortType.FLOAT}],
			"code_template": "cos({in_0})"
		},
		{
			"type": "MathPow",
			"title": "Power",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"inputs": [
				{"name": "Base", "port_type": PortType.FLOAT},
				{"name": "Exp", "port_type": PortType.FLOAT}
			],
			"outputs": [{"name": "Result", "port_type": PortType.FLOAT}],
			"code_template": "pow({in_0}, {in_1})"
		},
		{
			"type": "MathSqrt",
			"title": "Square Root",
			"category": "Math",
			"color": Color(0.2, 0.4, 0.7),
			"inputs": [{"name": "Value", "port_type": PortType.FLOAT}],
			"outputs": [{"name": "Result", "port_type": PortType.FLOAT}],
			"code_template": "sqrt({in_0})"
		},
		{
			"type": "MathRandom",
			"title": "Random Float",
			"category": "Math",
			"color": Color(0.3, 0.5, 0.8),
			"description": "Random float between 0.0 and 1.0.",
			"inputs": [],
			"outputs": [{"name": "Value", "port_type": PortType.FLOAT}],
			"code_template": "randf()"
		},
		{
			"type": "MathRandomRange",
			"title": "Random Range",
			"category": "Math",
			"color": Color(0.3, 0.5, 0.8),
			"inputs": [
				{"name": "Min", "port_type": PortType.FLOAT},
				{"name": "Max", "port_type": PortType.FLOAT}
			],
			"outputs": [{"name": "Value", "port_type": PortType.FLOAT}],
			"code_template": "randf_range({in_0}, {in_1})"
		},
		{
			"type": "ConstFloat",
			"title": "Float Constant",
			"category": "Math",
			"color": Color(0.2, 0.3, 0.6),
			"properties": [
				{"name": "value", "type": "float", "default": 0.0}
			],
			"inputs": [],
			"outputs": [{"name": "Value", "port_type": PortType.FLOAT}],
			"code_template": "{value}"
		},
		{
			"type": "ConstInt",
			"title": "Integer Constant",
			"category": "Math",
			"color": Color(0.2, 0.5, 0.3),
			"properties": [
				{"name": "value", "type": "int", "default": 0}
			],
			"inputs": [],
			"outputs": [{"name": "Value", "port_type": PortType.INT}],
			"code_template": "{value}"
		},
	]


# ─────────────────────────────────────────────
# LOGIC NODES
# ─────────────────────────────────────────────
static func _get_logic_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "LogicAnd",
			"title": "AND",
			"category": "Logic",
			"color": Color(0.7, 0.6, 0.1),
			"inputs": [
				{"name": "A", "port_type": PortType.BOOL},
				{"name": "B", "port_type": PortType.BOOL}
			],
			"outputs": [{"name": "Result", "port_type": PortType.BOOL}],
			"code_template": "{in_0} and {in_1}"
		},
		{
			"type": "LogicOr",
			"title": "OR",
			"category": "Logic",
			"color": Color(0.7, 0.6, 0.1),
			"inputs": [
				{"name": "A", "port_type": PortType.BOOL},
				{"name": "B", "port_type": PortType.BOOL}
			],
			"outputs": [{"name": "Result", "port_type": PortType.BOOL}],
			"code_template": "{in_0} or {in_1}"
		},
		{
			"type": "LogicNot",
			"title": "NOT",
			"category": "Logic",
			"color": Color(0.7, 0.6, 0.1),
			"inputs": [{"name": "Value", "port_type": PortType.BOOL}],
			"outputs": [{"name": "Result", "port_type": PortType.BOOL}],
			"code_template": "not {in_0}"
		},
		{
			"type": "LogicEqual",
			"title": "Equal (==)",
			"category": "Logic",
			"color": Color(0.7, 0.6, 0.1),
			"inputs": [
				{"name": "A", "port_type": PortType.ANY},
				{"name": "B", "port_type": PortType.ANY}
			],
			"outputs": [{"name": "Result", "port_type": PortType.BOOL}],
			"code_template": "{in_0} == {in_1}"
		},
		{
			"type": "LogicNotEqual",
			"title": "Not Equal (!=)",
			"category": "Logic",
			"color": Color(0.7, 0.6, 0.1),
			"inputs": [
				{"name": "A", "port_type": PortType.ANY},
				{"name": "B", "port_type": PortType.ANY}
			],
			"outputs": [{"name": "Result", "port_type": PortType.BOOL}],
			"code_template": "{in_0} != {in_1}"
		},
		{
			"type": "LogicGreater",
			"title": "Greater Than (>)",
			"category": "Logic",
			"color": Color(0.7, 0.6, 0.1),
			"inputs": [
				{"name": "A", "port_type": PortType.FLOAT},
				{"name": "B", "port_type": PortType.FLOAT}
			],
			"outputs": [{"name": "Result", "port_type": PortType.BOOL}],
			"code_template": "{in_0} > {in_1}"
		},
		{
			"type": "LogicLess",
			"title": "Less Than (<)",
			"category": "Logic",
			"color": Color(0.7, 0.6, 0.1),
			"inputs": [
				{"name": "A", "port_type": PortType.FLOAT},
				{"name": "B", "port_type": PortType.FLOAT}
			],
			"outputs": [{"name": "Result", "port_type": PortType.BOOL}],
			"code_template": "{in_0} < {in_1}"
		},
		{
			"type": "ConstBool",
			"title": "Boolean Constant",
			"category": "Logic",
			"color": Color(0.6, 0.5, 0.1),
			"properties": [
				{"name": "value", "type": "bool", "default": true}
			],
			"inputs": [],
			"outputs": [{"name": "Value", "port_type": PortType.BOOL}],
			"code_template": "{value}"
		},
	]


# ─────────────────────────────────────────────
# STRING NODES
# ─────────────────────────────────────────────
static func _get_string_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "ConstString",
			"title": "String Constant",
			"category": "String",
			"color": Color(0.7, 0.4, 0.1),
			"properties": [
				{"name": "value", "type": "string", "default": "Hello World"}
			],
			"inputs": [],
			"outputs": [{"name": "Value", "port_type": PortType.STRING}],
			"code_template": "\"{value}\""
		},
		{
			"type": "StringConcat",
			"title": "Concatenate",
			"category": "String",
			"color": Color(0.7, 0.4, 0.1),
			"inputs": [
				{"name": "A", "port_type": PortType.STRING},
				{"name": "B", "port_type": PortType.STRING}
			],
			"outputs": [{"name": "Result", "port_type": PortType.STRING}],
			"code_template": "{in_0} + {in_1}"
		},
		{
			"type": "StringLength",
			"title": "Length",
			"category": "String",
			"color": Color(0.7, 0.4, 0.1),
			"inputs": [{"name": "String", "port_type": PortType.STRING}],
			"outputs": [{"name": "Length", "port_type": PortType.INT}],
			"code_template": "len({in_0})"
		},
		{
			"type": "StringToInt",
			"title": "String to Int",
			"category": "String",
			"color": Color(0.7, 0.4, 0.1),
			"inputs": [{"name": "String", "port_type": PortType.STRING}],
			"outputs": [{"name": "Int", "port_type": PortType.INT}],
			"code_template": "int({in_0})"
		},
		{
			"type": "StringFormat",
			"title": "Format String",
			"category": "String",
			"color": Color(0.7, 0.4, 0.1),
			"properties": [
				{"name": "format", "type": "string", "default": "Value: %s"}
			],
			"inputs": [{"name": "Value", "port_type": PortType.ANY}],
			"outputs": [{"name": "Result", "port_type": PortType.STRING}],
			"code_template": "\"{format}\" % [{in_0}]"
		},
	]


# ─────────────────────────────────────────────
# VARIABLE NODES
# ─────────────────────────────────────────────
static func _get_variable_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "VarSet",
			"title": "Set Variable",
			"category": "Variables",
			"color": Color(0.5, 0.2, 0.6),
			"properties": [
				{"name": "var_name", "type": "string", "default": "my_var"}
			],
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Value", "port_type": PortType.ANY}
			],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW}
			],
			"code_template": "{var_name} = {in_1}"
		},
		{
			"type": "VarGet",
			"title": "Get Variable",
			"category": "Variables",
			"color": Color(0.5, 0.2, 0.6),
			"properties": [
				{"name": "var_name", "type": "string", "default": "my_var"}
			],
			"inputs": [],
			"outputs": [{"name": "Value", "port_type": PortType.ANY}],
			"code_template": "{var_name}"
		},
	]


# ─────────────────────────────────────────────
# NODE / SCENE NODES
# ─────────────────────────────────────────────
static func _get_node_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "NodeGetSelf",
			"title": "Self",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"inputs": [],
			"outputs": [{"name": "Self", "port_type": PortType.OBJECT}],
			"code_template": "self"
		},
		{
			"type": "NodeGetNode",
			"title": "Get Node",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"properties": [
				{"name": "path", "type": "string", "default": "NodeName"}
			],
			"inputs": [],
			"outputs": [{"name": "Node", "port_type": PortType.OBJECT}],
			"code_template": "get_node(\"{path}\")"
		},
		{
			"type": "NodeSetPosition",
			"title": "Set Position",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Node", "port_type": PortType.OBJECT},
				{"name": "Position", "port_type": PortType.VECTOR2}
			],
			"outputs": [{"name": "Flow", "port_type": PortType.FLOW}],
			"code_template": "{in_1}.position = {in_2}"
		},
		{
			"type": "NodeGetPosition",
			"title": "Get Position",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"inputs": [{"name": "Node", "port_type": PortType.OBJECT}],
			"outputs": [{"name": "Position", "port_type": PortType.VECTOR2}],
			"code_template": "{in_0}.position"
		},
		{
			"type": "NodeCallMethod",
			"title": "Call Method",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"properties": [
				{"name": "method", "type": "string", "default": "method_name"}
			],
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Target", "port_type": PortType.OBJECT}
			],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Return", "port_type": PortType.ANY}
			],
			"code_template": "{in_1}.{method}()"
		},
		{
			"type": "NodePrint",
			"title": "Print",
			"category": "Node",
			"color": Color(0.3, 0.3, 0.5),
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Value", "port_type": PortType.ANY}
			],
			"outputs": [{"name": "Flow", "port_type": PortType.FLOW}],
			"code_template": "print({in_1})"
		},
		{
			"type": "NodeQueueFree",
			"title": "Queue Free",
			"category": "Node",
			"color": Color(0.7, 0.2, 0.2),
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Node", "port_type": PortType.OBJECT}
			],
			"outputs": [{"name": "Flow", "port_type": PortType.FLOW}],
			"code_template": "{in_1}.queue_free()"
		},
		{
			"type": "NodeIsOnFloor",
			"title": "Is On Floor",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"inputs": [{"name": "Body", "port_type": PortType.OBJECT}],
			"outputs": [{"name": "On Floor", "port_type": PortType.BOOL}],
			"code_template": "{in_0}.is_on_floor()"
		},
		{
			"type": "NodeGetProperty",
			"title": "Get Property",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"properties": [
				{"name": "property", "type": "string", "default": "velocity"}
			],
			"inputs": [{"name": "Target", "port_type": PortType.OBJECT}],
			"outputs": [{"name": "Value", "port_type": PortType.ANY}],
			"code_template": "{in_0}.{property}"
		},
		{
			"type": "NodeSetProperty",
			"title": "Set Property",
			"category": "Node",
			"color": Color(0.5, 0.3, 0.1),
			"properties": [
				{"name": "property", "type": "string", "default": "velocity"}
			],
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Target", "port_type": PortType.OBJECT},
				{"name": "Value", "port_type": PortType.ANY}
			],
			"outputs": [{"name": "Flow", "port_type": PortType.FLOW}],
			"code_template": "{in_1}.{property} = {in_2}"
		},

		{
			"type": "NodeSetVelocity",
			"title": "Set Velocity",
			"category": "Node",
			"color": Color(0.4, 0.25, 0.15),
			"description": "Set velocity on CharacterBody2D/3D (or any object with velocity property).",
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Target", "port_type": PortType.OBJECT},
				{"name": "Velocity", "port_type": PortType.VECTOR2}
			],
			"outputs": [{"name": "Flow", "port_type": PortType.FLOW}],
			"code_template": "{in_1}.velocity = {in_2}"
		},
		{
			"type": "NodeGetVelocity",
			"title": "Get Velocity",
			"category": "Node",
			"color": Color(0.4, 0.25, 0.15),
			"description": "Get velocity from CharacterBody2D/3D.",
			"inputs": [{"name": "Target", "port_type": PortType.OBJECT}],
			"outputs": [{"name": "Velocity", "port_type": PortType.VECTOR2}],
			"code_template": "{in_0}.velocity"
		},
		{
			"type": "NodeMoveAndSlide",
			"title": "Move And Slide",
			"category": "Node",
			"color": Color(0.4, 0.25, 0.15),
			"description": "Call move_and_slide() on CharacterBody2D/3D.",
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Target", "port_type": PortType.OBJECT}
			],
			"outputs": [{"name": "Flow", "port_type": PortType.FLOW}],
			"code_template": "{in_1}.move_and_slide()"
		},
	]


# ─────────────────────────────────────────────
# VECTOR NODES
# ─────────────────────────────────────────────
static func _get_vector_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "Vector2Make",
			"title": "Make Vector2",
			"category": "Vector",
			"color": Color(0.5, 0.1, 0.7),
			"inputs": [
				{"name": "X", "port_type": PortType.FLOAT},
				{"name": "Y", "port_type": PortType.FLOAT}
			],
			"outputs": [{"name": "Vector2", "port_type": PortType.VECTOR2}],
			"code_template": "Vector2({in_0}, {in_1})"
		},
		{
			"type": "Vector2Break",
			"title": "Break Vector2",
			"category": "Vector",
			"color": Color(0.5, 0.1, 0.7),
			"inputs": [{"name": "Vector2", "port_type": PortType.VECTOR2}],
			"outputs": [
				{"name": "X", "port_type": PortType.FLOAT},
				{"name": "Y", "port_type": PortType.FLOAT}
			],
			"code_template": "{in_0}"
		},
		{
			"type": "Vector2Add",
			"title": "Add Vector2",
			"category": "Vector",
			"color": Color(0.5, 0.1, 0.7),
			"inputs": [
				{"name": "A", "port_type": PortType.VECTOR2},
				{"name": "B", "port_type": PortType.VECTOR2}
			],
			"outputs": [{"name": "Result", "port_type": PortType.VECTOR2}],
			"code_template": "{in_0} + {in_1}"
		},
		{
			"type": "Vector2Length",
			"title": "Vector2 Length",
			"category": "Vector",
			"color": Color(0.5, 0.1, 0.7),
			"inputs": [{"name": "Vector2", "port_type": PortType.VECTOR2}],
			"outputs": [{"name": "Length", "port_type": PortType.FLOAT}],
			"code_template": "{in_0}.length()"
		},
		{
			"type": "Vector2Normalize",
			"title": "Normalize Vector2",
			"category": "Vector",
			"color": Color(0.5, 0.1, 0.7),
			"inputs": [{"name": "Vector2", "port_type": PortType.VECTOR2}],
			"outputs": [{"name": "Normalized", "port_type": PortType.VECTOR2}],
			"code_template": "{in_0}.normalized()"
		},
		{
			"type": "ConstVector2",
			"title": "Vector2 Constant",
			"category": "Vector",
			"color": Color(0.4, 0.1, 0.6),
			"properties": [
				{"name": "x", "type": "float", "default": 0.0},
				{"name": "y", "type": "float", "default": 0.0}
			],
			"inputs": [],
			"outputs": [{"name": "Value", "port_type": PortType.VECTOR2}],
			"code_template": "Vector2({x}, {y})"
		},
		{
	"type": "Vector3Make",
	"title": "Make Vector3",
	"category": "Vector",
	"color": Color(0.5, 0.1, 0.7),
	"inputs": [
		{"name": "X", "port_type": PortType.FLOAT},
		{"name": "Y", "port_type": PortType.FLOAT},
		{"name": "Z", "port_type": PortType.FLOAT}
	],
	"outputs": [{"name": "Vector3", "port_type": PortType.VECTOR3}],
	"code_template": "Vector3({in_0}, {in_1}, {in_2})"
		},
		{
	"type": "Vector3Break",
	"title": "Break Vector3",
	"category": "Vector",
	"color": Color(0.5, 0.1, 0.7),
	"inputs": [{"name": "Vector3", "port_type": PortType.VECTOR3}],
	"outputs": [
		{"name": "X", "port_type": PortType.FLOAT},
		{"name": "Y", "port_type": PortType.FLOAT},
		{"name": "Z", "port_type": PortType.FLOAT}
	],
	"code_template": "{in_0}"
},
	]


# ─────────────────────────────────────────────
# INPUT NODES
# ─────────────────────────────────────────────
static func _get_input_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "InputIsActionPressed",
			"title": "Is Action Pressed",
			"category": "Input",
			"color": Color(0.2, 0.5, 0.5),
			"properties": [
				{"name": "action", "type": "string", "default": "ui_accept"}
			],
			"inputs": [],
			"outputs": [{"name": "Pressed", "port_type": PortType.BOOL}],
			"code_template": "Input.is_action_pressed(\"{action}\")"
		},
		{
			"type": "InputIsActionJustPressed",
			"title": "Is Action Just Pressed",
			"category": "Input",
			"color": Color(0.2, 0.5, 0.5),
			"properties": [
				{"name": "action", "type": "string", "default": "ui_accept"}
			],
			"inputs": [],
			"outputs": [{"name": "Pressed", "port_type": PortType.BOOL}],
			"code_template": "Input.is_action_just_pressed(\"{action}\")"
		},
		{
			"type": "InputGetAxis",
			"title": "Get Axis",
			"category": "Input",
			"color": Color(0.2, 0.5, 0.5),
			"properties": [
				{"name": "negative_action", "type": "string", "default": "ui_left"},
				{"name": "positive_action", "type": "string", "default": "ui_right"}
			],
			"inputs": [],
			"outputs": [{"name": "Axis", "port_type": PortType.FLOAT}],
			"code_template": "Input.get_axis(\"{negative_action}\", \"{positive_action}\")"
		},
		{
			"type": "InputGetVector",
			"title": "Get Vector",
			"category": "Input",
			"color": Color(0.2, 0.5, 0.5),
			"properties": [
				{"name": "neg_x", "type": "string", "default": "ui_left"},
				{"name": "pos_x", "type": "string", "default": "ui_right"},
				{"name": "neg_y", "type": "string", "default": "ui_up"},
				{"name": "pos_y", "type": "string", "default": "ui_down"}
			],
			"inputs": [],
			"outputs": [{"name": "Direction", "port_type": PortType.VECTOR2}],
			"code_template": "Input.get_vector(\"{neg_x}\", \"{pos_x}\", \"{neg_y}\", \"{pos_y}\")"
		},
	]


# ─────────────────────────────────────────────
# UTILITY NODES
# ─────────────────────────────────────────────
static func _get_utility_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "UtilityComment",
			"title": "Comment",
			"category": "Utility",
			"color": Color(0.3, 0.3, 0.3),
			"properties": [
				{"name": "text", "type": "string", "default": "Comment..."}
			],
			"inputs": [],
			"outputs": [],
			"code_template": "# {text}"
		},
		{
			"type": "UtilityReroute",
			"title": "Reroute",
			"category": "Utility",
			"color": Color(0.4, 0.4, 0.4),
			"inputs": [{"name": "", "port_type": PortType.ANY}],
			"outputs": [{"name": "", "port_type": PortType.ANY}],
			"code_template": "{in_0}"
		},
		{
			"type": "GetDelta",
			"title": "Get Delta",
			"category": "Utility",
			"color": Color(0.25, 0.45, 0.55),
			"description": "Frame delta time (from _process / _physics_process).",
			"inputs": [],
			"outputs": [{"name": "Delta", "port_type": PortType.FLOAT}],
			"code_template": "delta"
		},
		{
			"type": "GetSelf",
			"title": "Get Self (Owner)",
			"category": "Utility",
			"color": Color(0.5, 0.35, 0.2),
			"description": "Returns the node this visual script is running on (same as Node > Self).",
			"inputs": [],
			"outputs": [{"name": "Self", "port_type": PortType.OBJECT}],
			"code_template": "self"
		},
	]


# ─────────────────────────────────────────────
# TYPE NODES (declarations / casts)
# ─────────────────────────────────────────────
static func _get_type_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "DeclareVar",
			"title": "Declare Variable",
			"category": "Types",
			"color": Color(0.3, 0.5, 0.6),
			"description": "Declare a typed variable and optionally set its value.",
			"properties": [
				{"name": "var_name", "type": "string", "default": "my_var"},
				{"name": "var_type", "type": "string", "default": "float"}
			],
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Value", "port_type": PortType.ANY}
			],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Value", "port_type": PortType.ANY}
			],
			"code_template": "{var_name} = {in_1}"
		},
		{
			"type": "TypeCast",
			"title": "Cast / As",
			"category": "Types",
			"color": Color(0.3, 0.5, 0.6),
			"description": "Pass-through cast (helps type inference in export).",
			"properties": [
				{"name": "type_name", "type": "string", "default": "Node"}
			],
			"inputs": [{"name": "Value", "port_type": PortType.ANY}],
			"outputs": [{"name": "Casted", "port_type": PortType.ANY}],
			"code_template": "({in_0} as {type_name})"
		},
		{
			"type": "TypeIs",
			"title": "Is Type",
			"category": "Types",
			"color": Color(0.3, 0.5, 0.6),
			"description": "Check if value is of a given type.",
			"properties": [
				{"name": "type_name", "type": "string", "default": "CharacterBody2D"}
			],
			"inputs": [{"name": "Value", "port_type": PortType.ANY}],
			"outputs": [{"name": "Is", "port_type": PortType.BOOL}],
			"code_template": "{in_0} is {type_name}"
		},
		{
			"type": "ConstColor",
			"title": "Color Constant",
			"category": "Types",
			"color": Color(0.8, 0.2, 0.2),
			"properties": [
				{"name": "r", "type": "float", "default": 1.0},
				{"name": "g", "type": "float", "default": 1.0},
				{"name": "b", "type": "float", "default": 1.0},
				{"name": "a", "type": "float", "default": 1.0}
			],
			"inputs": [],
			"outputs": [{"name": "Color", "port_type": PortType.COLOR}],
			"code_template": "Color({r}, {g}, {b}, {a})"
		},
	]


# ─────────────────────────────────────────────
# FUNCTION / METHOD NODES
# ─────────────────────────────────────────────
static func _get_function_nodes() -> Array[Dictionary]:
	return [
		{
			"type": "FunctionDef",
			"title": "Define Function",
			"category": "Functions",
			"color": Color(0.4, 0.2, 0.6),
			"description": "Define a named function. Connect body flow from this node.",
			"properties": [
				{"name": "func_name", "type": "string", "default": "my_function"},
				{"name": "return_type", "type": "string", "default": "void"}
			],
			"inputs": [],
			"outputs": [{"name": "Body", "port_type": PortType.FLOW}],
			"code_template": "func {func_name}() -> {return_type}:\n\t{flow_out_0}"
		},
		{
			"type": "FunctionCall",
			"title": "Call Function",
			"category": "Functions",
			"color": Color(0.4, 0.2, 0.6),
			"description": "Call a previously defined function by name.",
			"properties": [
				{"name": "func_name", "type": "string", "default": "my_function"}
			],
			"inputs": [
				{"name": "Flow", "port_type": PortType.FLOW}
			],
			"outputs": [
				{"name": "Flow", "port_type": PortType.FLOW},
				{"name": "Return", "port_type": PortType.ANY}
			],
			"code_template": "{func_name}()"
		},
	]

